const devicesList = [
  // {'id': 2, 'address': 'DD:35:00:08:E1:91', 'name': 'fTdhermometerds'}
  {'id': 0, 'address': '00:00:00:00:00:00'},

  {'id': 1, 'address': 'F0:F8:F2:49:0F:84'}, //
  {'id': 2, 'address': 'F0:F8:F2:49:0F:78'}, //
  {'id': 3, 'address': 'F0:F8:F2:49:0D:6E'}, //
  {'id': 4, 'address': 'AC:4D:16:3E:F8:CF'}, //
  {'id': 5, 'address': 'F0:F8:F2:49:0F:6C'}, //
  {'id': 6, 'address': 'AC:4D:16:3E:F8:EA'}, //
  {'id': 7, 'address': 'AC:4D:16:3E:F4:EB'}, //
  {'id': 8, 'address': 'F0:F8:F2:49:0D:60'}, //
  {'id': 9, 'address': 'AC:4D:16:3E:F8:DA'}, //
  {'id': 10, 'address': 'AC:4D:16:3F:1C:AD'}, //
  {'id': 11, 'address': 'AC:4D:16:3F:1C:B9'}, //
  {'id': 12, 'address': 'F0:F8:F2:49:0F:86'}, //
  {'id': 13, 'address': 'AC:4D:16:3E:F8:F9'}, //
  {'id': 14, 'address': 'AC:4D:16:3E:F4:E7'}, //
  {'id': 15, 'address': 'AC:4D:16:3E:F4:E9'}, //
  {'id': 16, 'address': 'F0:F8:F2:49:0D:62'}, //
  {'id': 17, 'address': 'AC:4D:16:3F:1C:BB'}, //
  {'id': 18, 'address': 'AC:4D:16:3E:F8:C3'}, //
  {'id': 19, 'address': 'AC:4D:16:3F:1C:9C'}, //
  {'id': 20, 'address': 'AC:4D:16:3F:1C:A2'}, //
  {'id': 21, 'address': 'AC:4D:16:3F:1C:AF'}, //
  {'id': 22, 'address': 'F0:F8:F2:49:0D:8D'}, //
  {'id': 23, 'address': 'AC:4D:16:3E:F8:C1'}, // 이상함ㅐ0
  {'id': 24, 'address': 'F0:F8:F2:49:0F:7A'}, //
  {'id': 25, 'address': 'AC:4D:16:3F:1C:A9'}, //
];
