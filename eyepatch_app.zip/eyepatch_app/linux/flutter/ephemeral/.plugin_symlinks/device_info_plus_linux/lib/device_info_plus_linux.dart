/// The Linux implementation of `device_info_plus`.
library device_info_plus_linux;

export 'src/device_info.dart';
