## 6.0.0

 - Update a dependency to the latest release.

## 5.0.2

 - **FIX**: fixed wrong dependency version #1175.

## 5.0.1

 - **CHORE**: Version tagging using melos.

## 5.0.0

- Re-introduce: Add more information to WindowsDeviceInfo
- Update platform channel interface to 4.0.0

## 4.1.0

- Allow win32 3.x to be used.

## 4.0.0

- platform interface to 3.0.0

## 3.0.3

- Revert changes in 3.0.2

## 3.0.2

- Add more information to WindowsDeviceInfo.

## 3.0.1

- Update ffi to 2.0.1

## 3.0.0

- Update ffi to 2.0.0
- Update win32 to 2.7.0
- **Breaking change** Min Dart version is 2.17 now due to dependencies requirements

## 2.1.1

- Use automatic plugin registration
- update SDK to >=1.20.0

## 2.1.0

- add toMap to models

## 2.0.0

- device_info_plus_platform_interface upgrade to 2.0.0

## 1.0.1

- Improve documentation

## 1.0.0

- Initial null-safe release.
