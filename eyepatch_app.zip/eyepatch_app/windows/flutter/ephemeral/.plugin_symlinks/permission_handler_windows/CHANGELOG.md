# 0.1.1

* Added new Android 13 NEARBY_WIFI_DEVICES permission to permission_constants.h

## 0.1.0

* Adds an initial implementation of Windows support for the permission_handler plugin.
