package com.tekartik.sqflite;

import android.content.Context;

/**
 * Allow creating the object directly
 */
public class TestSqflitePlugin extends SqflitePlugin {
    public TestSqflitePlugin(Context context) {
        super(context);
    }
}
