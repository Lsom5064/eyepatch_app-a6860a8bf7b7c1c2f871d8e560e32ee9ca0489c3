// @dart = 2.9
import 'package:integration_test/integration_test_driver.dart';

Future<void> main() => integrationDriver();
