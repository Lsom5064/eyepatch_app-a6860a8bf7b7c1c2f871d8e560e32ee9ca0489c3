# Device Info Plus macOS

[![Flutter Community: device_info_plus_macos](https://fluttercommunity.dev/_github/header/device_info_plus_macos)](https://github.com/fluttercommunity/community)

[![pub package](https://img.shields.io/pub/v/device_info_plus_macos.svg)](https://pub.dev/packages/device_info_plus_macos)

The macOS implementation of [`device_info_plus`](https://pub.dev/packages/device_info_plus).

## Usage

This package is already included as part of the `device_info_plus` package dependency, and will
be included when using `device_info_plus` as normal.
