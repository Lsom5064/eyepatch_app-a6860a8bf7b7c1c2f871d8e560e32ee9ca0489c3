## 5.0.0

 - Update a dependency to the latest release.

## 4.0.2

 - **FIX**: fixed wrong dependency version #1175.

## 4.0.1

 - **CHORE**: Version tagging using melos.

## 4.0.0

- platform interface to 4.0.0

## 3.0.0

- platform interface to 3.0.0

## 2.2.3

- Fix crash on macOS running on Apple M1

## 2.2.2

- Fixed incorrect computer name and version on MacOS

## 2.2.1

- Fix build warnings

## 2.2.0

- add System GUID to MacOS

## 2.1.0

- add toMap to models

## 2.0.0

- device_info_plus_platform_interface upgrade to 2.0.0

## 1.0.1

- Improve documentation

## 1.0.0

- Migrated to null safety

## 0.1.1

- Update dependencies.

## 0.1.0

- Initial release.
