package com.example.eyepatch_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
